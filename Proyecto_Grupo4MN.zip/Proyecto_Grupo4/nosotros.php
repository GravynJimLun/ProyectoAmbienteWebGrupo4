<?php include 'partials/header.php'; ?>

<div class="container mt-4">
  <div class="p-5 mb-4 bg-light rounded-3 shadow-sm">
    <div class="container-fluid py-5">
      <h1 class="display-5 fw-bold">Sobre Nosotros</h1>
      <p class="col-md-8 fs-5">
        En <strong>AgroEscazú</strong> nos dedicamos al cuidado integral de las mascotas, 
        ofreciendo servicios veterinarios de alta calidad y un completo inventario de productos.
        Nuestro compromiso es garantizar la salud y bienestar de cada paciente con atención personalizada y profesional.
      </p>
      <p class="col-md-8 fs-5">
        Contamos con un equipo de veterinarios especializados, instalaciones modernas y un enfoque humano 
        para que tú y tu mascota se sientan siempre en confianza.
      </p>
    </div>
  </div>

  <div class="row text-center">
    <div class="col-md-4">
      <div class="card border-0 shadow-sm h-100">
        <div class="card-body">
          <h5 class="card-title">Misión</h5>
          <p class="card-text">
            Brindar servicios veterinarios confiables y accesibles, cuidando de la salud animal con pasión y dedicación.
          </p>
        </div>
      </div>
    </div>

    <div class="col-md-4">
      <div class="card border-0 shadow-sm h-100">
        <div class="card-body">
          <h5 class="card-title">Visión</h5>
          <p class="card-text">
            Ser la clínica veterinaria líder en Escazú y sus alrededores, reconocida por la calidad, confianza y amor hacia los animales.
          </p>
        </div>
      </div>
    </div>

    <div class="col-md-4">
      <div class="card border-0 shadow-sm h-100">
        <div class="card-body">
          <h5 class="card-title">Valores</h5>
          <p class="card-text">
            Respeto, compromiso, ética profesional, innovación y empatía hacia nuestros pacientes y clientes.
          </p>
        </div>
      </div>
    </div>
  </div>
</div>

<?php include 'partials/footer.php'; ?>

