$(function(){
  const $tbody = $("#tablaProductos tbody");
  const api = {
    list: ()=>fetch('api/productos_list.php').then(r=>r.json()),
    save: (form)=>fetch('api/productos_save.php',{method:'POST',body:form}).then(r=>r.json()),
    del: (id)=>fetch('api/productos_delete.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'id='+encodeURIComponent(id)}).then(r=>r.json()),
  };
  function cargar(){
    api.list().then(rows=>{
      $tbody.empty();
      rows.forEach(r=>{
        const tr = $(`<tr>
          <td>${r.id}</td>
          <td>${r.nombre}</td>
          <td>${r.nombre_marca || ''}</td>
          <td>${r.nombre_categoria || ''}</td>
          <td>${r.precio}</td>
          <td>${r.stock}</td>
          <td>
            <button class="btn btn-sm btn-primary btn-edit">Editar</button>
            <button class="btn btn-sm btn-danger btn-del">Eliminar</button>
          </td>
        </tr>`);
        tr.find(".btn-edit").on('click', ()=>{
          $("#prod_id").val(r.id);
          $("#nombre").val(r.nombre);
          $("#marca").val(r.id_marca);
          $("#categoria").val(r.id_categoria);
          $("#precio").val(r.precio);
          $("#stock").val(r.stock);
        });
        tr.find(".btn-del").on('click', ()=>{
          if(confirm('¿Eliminar producto?')){ api.del(r.id).then(()=>cargar()); }
        });
        $tbody.append(tr);
      });
    });
  }
  cargar();
  $("#btnLimpiar").on('click', ()=>{ $("#formProducto")[0].reset(); $("#prod_id").val(''); });
  $("#formProducto").on('submit', function(e){
    e.preventDefault();
    api.save(new FormData(this)).then(()=>{ this.reset(); $("#prod_id").val(''); cargar(); });
  });
});
