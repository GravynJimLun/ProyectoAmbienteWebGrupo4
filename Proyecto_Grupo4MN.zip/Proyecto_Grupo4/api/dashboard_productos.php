<?php
require_once '../include/conexion.php';
header('Content-Type: application/json; charset=utf-8');
$res = $mysqli->query("SELECT nombre, stock FROM productos ORDER BY stock DESC LIMIT 5");
$labels=[];$data=[];
while($r=$res->fetch_assoc()){ $labels[]=$r['nombre']; $data[]=(int)$r['stock']; }
echo json_encode(['labels'=>$labels,'data'=>$data]);
