<?php
require_once '../include/conexion.php';

$id_cliente = $_POST['id_cliente'] ?? '';
$nom_cliente = $_POST['nom_cliente'] ?? '';
$mascota = $_POST['mascota'] ?? '';
$servicio = $_POST['servicio'] ?? '';
$precio = $_POST['precio'] ?? 0;
$fecha = $_POST['fecha'] ?? '';

$stmt = $mysqli->prepare("INSERT INTO citas (id_cliente, nom_cliente, mascota, servicio, precio, fecha) VALUES (?, ?, ?, ?, ?, ?)");
$stmt->bind_param("isssds", $id_cliente, $nom_cliente, $mascota, $servicio, $precio, $fecha);
$stmt->execute();

echo json_encode(['ok' => true]);
