<?php
include 'partials/header.php';
include 'include/seguridad.php';
include 'include/conexion.php';

// Obtener categorías y marcas
$categorias = $mysqli->query("SELECT id_categoria, nombre_categoria FROM categorias ORDER BY nombre_categoria");
$marcas = $mysqli->query("SELECT id_marca, nombre_marca FROM marcas ORDER BY nombre_marca");
?>
<h3>Gestión de Productos</h3>
<div class="row g-3">
  <div class="col-md-4">
    <div class="card"><div class="card-body">
      <h5>Nuevo / Editar</h5>
      <form id="formProducto">
        <input type="hidden" name="id" id="prod_id">
        <div class="mb-2"><label class="form-label">Nombre</label><input class="form-control" name="nombre" id="nombre" required></div>
        <div class="mb-2">
          <label class="form-label">Marca</label>
          <div class="input-group">
            <select class="form-control" name="marca" id="marca" required>
              <option value="">Seleccione una marca</option>
              <?php while($m = $marcas->fetch_assoc()): ?>
                <option value="<?= $m['id_marca'] ?>"><?= htmlspecialchars($m['nombre_marca']) ?></option>
              <?php endwhile; ?>
            </select>
            <a href="marca.php" class="btn btn-outline-secondary" title="Agregar Marca" target="_blank">+</a>
          </div>
        </div>
        <div class="mb-2">
          <label class="form-label">Categoría</label>
          <div class="input-group">
            <select class="form-control" name="categoria" id="categoria" required>
              <option value="">Seleccione una categoría</option>
              <?php while($c = $categorias->fetch_assoc()): ?>
                <option value="<?= $c['id_categoria'] ?>"><?= htmlspecialchars($c['nombre_categoria']) ?></option>
              <?php endwhile; ?>
            </select>
            <a href="categoria.php" class="btn btn-outline-secondary" title="Agregar Categoría" target="_blank">+</a>
          </div>
        </div>
        <div class="mb-2"><label class="form-label">Precio</label><input type="number" step="0.01" class="form-control" name="precio" id="precio" required></div>
        <div class="mb-2"><label class="form-label">Stock</label><input type="number" class="form-control" name="stock" id="stock" required></div>
        <button class="btn btn-success mt-2" type="submit">Guardar</button>
        <button class="btn btn-secondary mt-2" type="button" id="btnLimpiar">Limpiar</button>
      </form>
    </div></div>
  </div>
  <div class="col-md-8">
    <div class="card"><div class="card-body">
      <h5>Listado</h5>
      <table class="table table-striped" id="tablaProductos">
        <thead><tr><th>ID</th><th>Nombre</th><th>Marca</th><th>Categoría</th><th>Precio</th><th>Stock</th><th>Acciones</th></tr></thead>
        <tbody></tbody>
      </table>
    </div></div>
  </div>
</div>
<script src="assets/js/productos.js"></script>
<?php include 'partials/footer.php'; ?>