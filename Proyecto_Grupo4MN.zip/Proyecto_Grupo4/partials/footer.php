
</div>
<footer class="footer mt-auto py-3 bg-dark text-white text-center">
  <div class="container">
    <span>© 2025 AgroEscazú | Clínica Veterinaria</span>
  </div>
</footer>
</body>
</html>
