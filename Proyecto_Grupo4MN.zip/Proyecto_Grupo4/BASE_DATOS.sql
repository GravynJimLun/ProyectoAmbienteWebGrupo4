CREATE DATABASE IF NOT EXISTS proyecto_web CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE proyecto_web;

CREATE TABLE IF NOT EXISTS roles (
  id INT PRIMARY KEY,
  nombre VARCHAR(50) NOT NULL UNIQUE
);

INSERT IGNORE INTO roles (id, nombre) VALUES (1,'admin'),(2,'cliente'),(3,'veterinario');

CREATE TABLE IF NOT EXISTS clientes (
 id_cliente INT AUTO_INCREMENT PRIMARY KEY,
 identificacion VARCHAR(20) NOT NULL UNIQUE,
 apellidos VARCHAR(100) NOT NULL,
 nombre VARCHAR(100) NOT NULL,
 telefono_personal VARCHAR(20),
 direccion_personal VARCHAR(255),
 email VARCHAR(150) UNIQUE,
 usuario VARCHAR(50) NOT NULL UNIQUE,
 contrasena VARCHAR(255) NOT NULL,
 role_id INT NOT NULL DEFAULT 2,
 FOREIGN KEY (role_id) REFERENCES roles(id)
);

CREATE TABLE IF NOT EXISTS productos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(120) NOT NULL,
  marca VARCHAR(100),
  categoria VARCHAR(100),
  precio DECIMAL(10,2) NOT NULL DEFAULT 0,
  stock INT NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS citas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom_cliente VARCHAR(100) NOT NULL,
    mascota VARCHAR(100) NOT NULL,
    servicio VARCHAR(100) NOT NULL,
    precio DECIMAL(10,2) NOT NULL,
    fecha DATETIME NOT NULL
);

CREATE TABLE categorias (
    id_categoria INT AUTO_INCREMENT PRIMARY KEY,
    nombre_categoria VARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE marcas (
    id_marca INT AUTO_INCREMENT PRIMARY KEY,
    nombre_marca VARCHAR(100) NOT NULL UNIQUE
);

-- Nueva tabla usuarios
CREATE TABLE IF NOT EXISTS usuarios (
  id_usuario INT AUTO_INCREMENT PRIMARY KEY,
  usuario VARCHAR(50) NOT NULL UNIQUE,
  contrasena VARCHAR(255) NOT NULL,
  email VARCHAR(150) UNIQUE,
  id_rol INT NOT NULL,
  FOREIGN KEY (id_rol) REFERENCES roles(id)
);

-- Ajusta clientes: elimina campos de login y rol
ALTER TABLE clientes
  DROP COLUMN usuario,
  DROP COLUMN contrasena,
  DROP COLUMN role_id;

ALTER TABLE productos
  ADD id_categoria INT,
  ADD id_marca INT,
  ADD FOREIGN KEY (id_categoria) REFERENCES categorias(id_categoria),
  ADD FOREIGN KEY (id_marca) REFERENCES marcas(id_marca);
  
ALTER TABLE citas ADD COLUMN id_cliente INT, ADD FOREIGN KEY (id_cliente) REFERENCES clientes(id_cliente);  

INSERT INTO categorias (nombre_categoria) VALUES ('Medicamentos'), ('Alimentos'), ('Accesorios');
INSERT INTO marcas (nombre_marca) VALUES ('Bayer'), ('Purina'), ('PetSafe');


Admin por defecto (usuario: admin / pass: admin)
INSERT IGNORE INTO clientes (identificacion, apellidos, nombre, telefono_personal, direccion_personal, email, usuario, contrasena, role_id)
VALUES ('000000000','Admin','General','00000000','Oficina','admin@prueba.com','admin', 'admin', 1);