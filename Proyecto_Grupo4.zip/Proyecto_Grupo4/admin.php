<?php include 'partials/header.php'; include 'include/seguridad.php';
if ($_SESSION['role_id']!=1){ echo '<div class="alert alert-danger">Acceso restringido.</div>'; include 'partials/footer.php'; exit; }
?>
<h3>Panel Administrativo</h3>
<div class="row g-3">
  <div class="col-md-6">
    <div class="card"><div class="card-body">
      <h5>Usuarios</h5>
      <table class="table table-sm" id="tablaUsuarios">
        <thead><tr><th>ID</th><th>Nombre</th><th>Usuario</th><th>Rol</th></tr></thead>
        <tbody>
          <?php require_once 'include/conexion.php';
          $res = $mysqli->query("SELECT c.id_cliente, CONCAT(c.nombre,' ',c.apellidos) as nom, c.usuario, r.nombre rol FROM clientes c JOIN roles r ON r.id=c.role_id ORDER BY c.id_cliente DESC");
          while($r=$res->fetch_assoc()){ echo '<tr><td>'.$r['id_cliente'].'</td><td>'.htmlspecialchars($r['nom']).'</td><td>'.htmlspecialchars($r['usuario']).'</td><td>'.htmlspecialchars($r['rol']).'</td></tr>'; } ?>
        </tbody>
      </table>
    </div></div>
  </div>
  <div class="col-md-6">
    <div class="card"><div class="card-body">
      <h5>Asignar rol</h5>
      <form method="post">
        <div class="mb-2"><label class="form-label">ID Usuario</label><input name="id" class="form-control" required></div>
        <div class="mb-2"><label class="form-label">Rol</label>
          <select name="role_id" class="form-select"><?php $r=$mysqli->query('SELECT * FROM roles'); while($x=$r->fetch_assoc()){ echo '<option value="'.$x['id'].'">'.$x['nombre'].'</option>'; } ?></select>
        </div>
        <button class="btn btn-primary">Actualizar</button>
      </form>
      <?php
      if ($_SERVER['REQUEST_METHOD']==='POST') {
        $id = intval($_POST['id']); $role = intval($_POST['role_id']);
        $stmt = $mysqli->prepare("UPDATE clientes SET role_id=? WHERE id_cliente=?");
        $stmt->bind_param('ii',$role,$id); $stmt->execute();
        echo '<div class="alert alert-success mt-2">Rol actualizado</div>';
      } ?>
    </div></div>
  </div>
</div>
<?php include 'partials/footer.php'; ?>
