<?php
include "include/conexion.php";
include "include/seguridad.php";

$mensaje = "";

// Desactivar reportes de errores para evitar mostrar detalles sensibles
mysqli_report(MYSQLI_REPORT_OFF);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = trim($_POST["nombre"]);
    if ($nombre != "") {
        $stmt = $mysqli->prepare("INSERT INTO marcas (nombre_marca) VALUES (?)");
        $stmt->bind_param("s", $nombre);
        if ($stmt->execute()) {
            header("Location: productos.php");
            exit;
        } else {
            if ($stmt->errno == 1062) {
                $mensaje = "La marca ya existe.";
            } else {
                $mensaje = "Error al registrar la marca.";
            }
        }
    }
}
$marcas = $mysqli->query("SELECT * FROM marcas ORDER BY nombre_marca");
?>
<?php include "partials/header.php"; ?>
<div class="container mt-5">
  <h2>Registrar Marca</h2>

  <?php if($mensaje): ?>
    <div class="alert alert-warning"><?= $mensaje ?></div>
  <?php endif; ?>

  <form method="post" class="mb-4 d-flex">
    <input type="text" name="nombre" class="form-control me-2" placeholder="Nombre de la marca" required>
    <button type="submit" class="btn btn-primary">Guardar</button>
  </form>

  <h3>Marcas existentes</h3>
  <ul class="list-group">
    <?php while($m = $marcas->fetch_assoc()): ?>
      <li class="list-group-item"><?= htmlspecialchars($m["nombre_marca"]) ?></li>
    <?php endwhile; ?>
  </ul>
</div>
<?php include "partials/footer.php"; ?>


