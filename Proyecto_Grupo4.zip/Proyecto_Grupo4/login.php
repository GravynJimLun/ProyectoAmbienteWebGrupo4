<?php
session_start();
require_once 'include/conexion.php';

$error = '';
if ($_SERVER['REQUEST_METHOD']==='POST') {
  $usuario = $_POST['usuario'] ?? '';
  $pass = $_POST['contrasena'] ?? '';
  $stmt = $mysqli->prepare("SELECT id_cliente, usuario, contrasena, role_id, nombre, apellidos FROM clientes WHERE usuario=?");
  $stmt->bind_param('s', $usuario);
  $stmt->execute();
  $res = $stmt->get_result();
  if ($u = $res->fetch_assoc()) {
    if (password_verify($pass, $u['contrasena'])) {
      $_SESSION['id_cliente'] = $u['id_cliente'];
      $_SESSION['usuario'] = $u['usuario'];
      $_SESSION['role_id'] = (int)$u['role_id'];
      $_SESSION['nombre'] = $u['nombre'];
      $_SESSION['apellidos'] = $u['apellidos'];
      header('Location: index.php'); exit;
    }
  }
  $error = 'Usuario o contraseña incorrectos';
}
?>
<?php include 'partials/header.php'; ?>
<div class="row justify-content-center">
  <div class="col-md-6">
    <div class="card">
      <div class="card-body">
        <h4 class="mb-3">Iniciar sesión</h4>
        <?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
        <form method="post" autocomplete="off">
          <div class="mb-3">
            <label class="form-label">Usuario</label>
            <input name="usuario" class="form-control" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Contraseña</label>
            <input type="password" name="contrasena" class="form-control" required>
          </div>
          <button class="btn btn-success">Ingresar</button>
          <a class="btn btn-link" href="register.php">Crear cuenta</a>
        </form>
      </div>
    </div>
  </div>
</div>
<?php include 'partials/footer.php'; ?>