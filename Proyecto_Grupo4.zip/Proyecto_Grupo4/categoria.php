<?php
include "include/conexion.php";
include "include/seguridad.php";

$mensaje = "";

mysqli_report(MYSQLI_REPORT_OFF);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = trim($_POST["nombre"]);
    if ($nombre != "") {
        $stmt = $mysqli->prepare("INSERT INTO categorias (nombre_categoria) VALUES (?)");
        $stmt->bind_param("s", $nombre);
        if ($stmt->execute()) {
            header("Location: productos.php");
            exit;
        } else {
            if ($stmt->errno == 1062) {
                $mensaje = "La categoría ya existe.";
            } else {
                $mensaje = "Error al registrar la categoría.";
            }
        }
    }
}
$categorias = $mysqli->query("SELECT * FROM categorias ORDER BY nombre_categoria");
?>
<?php include "partials/header.php"; ?>
<div class="container mt-5">
  <h2>Registrar Categoría</h2>

  <?php if($mensaje): ?>
    <div class="alert alert-warning"><?= $mensaje ?></div>
  <?php endif; ?>

  <form method="post" class="mb-4 d-flex">
    <input type="text" name="nombre" class="form-control me-2" placeholder="Nombre de la categoría" required>
    <button type="submit" class="btn btn-primary">Guardar</button>
  </form>

  <h3>Categorías existentes</h3>
  <ul class="list-group">
    <?php while($c = $categorias->fetch_assoc()): ?>
      <li class="list-group-item"><?= htmlspecialchars($c["nombre_categoria"]) ?></li>
    <?php endwhile; ?>
  </ul>
</div>
<?php include "partials/footer.php"; ?>

