<?php
require_once '../include/conexion.php';
header('Content-Type: application/json; charset=utf-8');
$query = "SELECT p.id, p.nombre, m.nombre_marca, c.nombre_categoria, p.precio, p.stock, 
                 p.id_marca, p.id_categoria
          FROM productos p
          LEFT JOIN marcas m ON p.id_marca = m.id_marca
          LEFT JOIN categorias c ON p.id_categoria = c.id_categoria
          ORDER BY p.id DESC";
$result = $mysqli->query($query);

$productos = [];
while($row = $result->fetch_assoc()) {
    $productos[] = $row;
}
echo json_encode($productos);
?>
