<?php
require_once '../include/conexion.php';
header('Content-Type: application/json; charset=utf-8');
$rows = [];
for ($i=6; $i>=0; $i--) {
  $day = date('Y-m-d', strtotime("-$i day"));
  $stmt = $mysqli->prepare("SELECT COUNT(*) c FROM citas WHERE DATE(fecha)=?");
  $stmt->bind_param('s', $day);
  $stmt->execute();
  $c = $stmt->get_result()->fetch_assoc()['c'] ?? 0;
  $rows[] = ['label'=>$day, 'c'=>$c];
}
echo json_encode(['labels'=>array_column($rows,'label'),'data'=>array_column($rows,'c')]);
