<?php
include '../include/conexion.php';

$id = $_POST['id'] ?? '';
$nombre = $_POST['nombre'] ?? '';
$marca = $_POST['marca'] ?? '';
$categoria = $_POST['categoria'] ?? '';
$precio = $_POST['precio'] ?? '';
$stock = $_POST['stock'] ?? '';

if ($id) {
    // Actualizar
    $stmt = $mysqli->prepare("UPDATE productos SET nombre=?, id_marca=?, id_categoria=?, precio=?, stock=? WHERE id=?");
    $stmt->bind_param("siidii", $nombre, $marca, $categoria, $precio, $stock, $id);
    $stmt->execute();
} else {
    // Insertar
    $stmt = $mysqli->prepare("INSERT INTO productos (nombre, id_marca, id_categoria, precio, stock) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("siidi", $nombre, $marca, $categoria, $precio, $stock);
    $stmt->execute();
}
echo json_encode(['ok'=>true]);
