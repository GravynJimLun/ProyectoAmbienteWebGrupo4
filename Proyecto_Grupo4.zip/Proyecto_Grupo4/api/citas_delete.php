<?php
require_once '../include/conexion.php';
if ($_SERVER['REQUEST_METHOD']!=='POST') { http_response_code(405); exit; }
$id = intval($_POST['id'] ?? 0);
$stmt = $mysqli->prepare("DELETE FROM citas WHERE id=?");
$stmt->bind_param('i', $id);
$stmt->execute();
header('Content-Type: application/json'); echo json_encode(['ok'=>true]);
