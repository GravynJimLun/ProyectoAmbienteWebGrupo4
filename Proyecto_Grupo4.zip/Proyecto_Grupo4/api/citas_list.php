<?php
require_once '../include/conexion.php';
header('Content-Type: application/json; charset=utf-8');
$res = $mysqli->query("SELECT id, CONCAT(mascota,' - ',servicio) AS title, fecha AS start FROM citas");
$events = [];
while($r=$res->fetch_assoc()){ $events[] = $r; }
echo json_encode($events);
