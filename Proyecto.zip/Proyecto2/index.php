<?php include 'partials/header.php'; ?>
<div class="p-4 bg-light rounded-3">
  <div class="container-fluid py-2">
    <h1 class="display-6 fw-bold">Bienvenido a AgroEscazú</h1>
    <p class="col-md-8 fs-5">Gestión de citas veterinarias e inventario de productos. Inicia sesión para gestionar tu información.</p>
  </div>
</div>

<div class="row mt-4 g-3">
  <div class="col-md-6">
    <div class="card h-100">
      <div class="card-body">
        <h5 class="card-title">Citas de esta semana</h5>
        <canvas id="chartCitas"></canvas>
      </div>
    </div>
  </div>
  <div class="col-md-6">
    <div class="card h-100">
      <div class="card-body">
        <h5 class="card-title">Top productos por stock</h5>
        <canvas id="chartProductos"></canvas>
      </div>
    </div>
  </div>
</div>

<script>
fetch('api/dashboard_citas.php').then(r=>r.json()).then(d=>{
  new Chart(document.getElementById('chartCitas'), {type:'bar', data:{labels:d.labels, datasets:[{label:'Citas', data:d.data}]}});
});
fetch('api/dashboard_productos.php').then(r=>r.json()).then(d=>{
  new Chart(document.getElementById('chartProductos'), {type:'bar', data:{labels:d.labels, datasets:[{label:'Stock', data:d.data}]}});
});
</script>
<?php include 'partials/footer.php'; ?>