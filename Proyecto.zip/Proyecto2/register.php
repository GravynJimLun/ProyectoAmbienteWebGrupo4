<?php
session_start();
require_once 'include/conexion.php';
$msg = ''; $error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
  $identificacion = $_POST['identificacion'];
  $apellidos = $_POST['apellidos'];
  $nombre = $_POST['nombre'];
  $telefono = $_POST['telefono'];
  $direccion = $_POST['direccion'];
  $email = $_POST['email'];
  $usuario = $_POST['usuario'];
  $pass = password_hash($_POST['contrasena'], PASSWORD_BCRYPT);
  $stmt = $mysqli->prepare("INSERT INTO clientes (identificacion, apellidos, nombre, telefono_personal, direccion_personal, email, usuario, contrasena, role_id) VALUES (?,?,?,?,?,?,?,?,2)");
  $stmt->bind_param('ssssssss', $identificacion,$apellidos,$nombre,$telefono,$direccion,$email,$usuario,$pass);
  try {
    $stmt->execute();
    $msg = 'Registro exitoso, ahora puedes iniciar sesión.';
  } catch (Exception $e) { $error = 'Error: ' . $e->getMessage(); }
}
?>
<?php include 'partials/header.php'; ?>
<div class="row justify-content-center">
  <div class="col-md-8">
    <div class="card"><div class="card-body">
      <h4 class="mb-3">Crear cuenta</h4>
      <?php if ($msg): ?><div class="alert alert-success"><?= htmlspecialchars($msg) ?></div><?php endif; ?>
      <?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
      <form method="post" autocomplete="off">
        <div class="row g-3">
          <div class="col-md-4"><label class="form-label">Identificación</label><input name="identificacion" class="form-control" required></div>
          <div class="col-md-4"><label class="form-label">Nombre</label><input name="nombre" class="form-control" required></div>
          <div class="col-md-4"><label class="form-label">Apellidos</label><input name="apellidos" class="form-control" required></div>
          <div class="col-md-4"><label class="form-label">Teléfono</label><input name="telefono" class="form-control"></div>
          <div class="col-md-8"><label class="form-label">Dirección</label><input name="direccion" class="form-control"></div>
          <div class="col-md-6"><label class="form-label">Email</label><input type="email" name="email" class="form-control"></div>
          <div class="col-md-3"><label class="form-label">Usuario</label><input name="usuario" class="form-control" required></div>
          <div class="col-md-3"><label class="form-label">Contraseña</label><input type="password" name="contrasena" class="form-control" required></div>
        </div>
        <div class="mt-3"><button class="btn btn-primary">Registrarme</button></div>
      </form>
    </div></div>
  </div>
</div>
<?php include 'partials/footer.php'; ?>