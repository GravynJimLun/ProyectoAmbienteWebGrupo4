<?php
require_once '../include/conexion.php';
if ($_SERVER['REQUEST_METHOD']!=='POST') { http_response_code(405); exit; }
$nom = $_POST['nom_cliente'] ?? '';
$mascota = $_POST['mascota'] ?? '';
$servicio = $_POST['servicio'] ?? '';
$precio = floatval($_POST['precio'] ?? 0);
$fecha = $_POST['fecha'] ?? date('Y-m-d H:i:s');
$stmt = $mysqli->prepare("INSERT INTO citas (nom_cliente, mascota, servicio, precio, fecha) VALUES (?,?,?,?,?)");
$stmt->bind_param('sssds', $nom,$mascota,$servicio,$precio,$fecha);
$stmt->execute();
header('Content-Type: application/json'); echo json_encode(['ok'=>true]);
