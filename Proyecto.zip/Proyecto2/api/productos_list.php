<?php
require_once '../include/conexion.php';
header('Content-Type: application/json; charset=utf-8');
$res = $mysqli->query("SELECT * FROM productos ORDER BY id DESC");
echo json_encode($res->fetch_all(MYSQLI_ASSOC));
