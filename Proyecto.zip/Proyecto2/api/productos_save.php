<?php
require_once '../include/conexion.php';
if ($_SERVER['REQUEST_METHOD']!=='POST') { http_response_code(405); exit; }
$id = $_POST['id'] ?? '';
$nombre = $_POST['nombre'] ?? '';
$marca = $_POST['marca'] ?? '';
$categoria = $_POST['categoria'] ?? '';
$precio = $_POST['precio'] ?? 0;
$stock = $_POST['stock'] ?? 0;
if ($id) {
  $stmt = $mysqli->prepare("UPDATE productos SET nombre=?, marca=?, categoria=?, precio=?, stock=? WHERE id=?");
  $stmt->bind_param('sssdis', $nombre,$marca,$categoria,$precio,$stock,$id);
  $stmt->execute();
} else {
  $stmt = $mysqli->prepare("INSERT INTO productos (nombre, marca, categoria, precio, stock) VALUES (?,?,?,?,?)");
  $stmt->bind_param('sssdi', $nombre,$marca,$categoria,$precio,$stock);
  $stmt->execute();
}
header('Content-Type: application/json'); echo json_encode(['ok'=>true]);
