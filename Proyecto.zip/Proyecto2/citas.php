<?php include 'partials/header.php'; include 'include/seguridad.php'; ?>
<div class="row">
  <div class="col-md-8">
    <div id='calendar'></div>
  </div>
  <div class="col-md-4">
    <div class="card"><div class="card-body">
      <h5>Nueva cita</h5>
      <form id="formCita">
        <div class="mb-2"><label class="form-label">Cliente</label><input class="form-control" name="nom_cliente" required value="<?= htmlspecialchars($_SESSION['nombre'].' '.$_SESSION['apellidos']) ?>"></div>
        <div class="mb-2"><label class="form-label">Mascota</label><input class="form-control" name="mascota" required></div>
        <div class="mb-2"><label class="form-label">Servicio</label><input class="form-control" name="servicio" required></div>
        <div class="mb-2"><label class="form-label">Precio</label><input type="number" step="0.01" class="form-control" name="precio" required></div>
        <div class="mb-2"><label class="form-label">Fecha y hora</label><input type="datetime-local" class="form-control" name="fecha" required></div>
        <button class="btn btn-success mt-2">Guardar</button>
      </form>
      <div id="msg" class="mt-2"></div>
    </div></div>
  </div>
</div>
<script>
document.addEventListener('DOMContentLoaded', function() {
  var calendarEl = document.getElementById('calendar');
  var calendar = new FullCalendar.Calendar(calendarEl, {
    initialView: 'dayGridMonth',
    headerToolbar: { left: 'prev,next today', center: 'title', right: 'dayGridMonth,timeGridWeek,timeGridDay' },
    events: 'api/citas_list.php',
    eventClick: function(info){
      if (confirm('¿Eliminar esta cita?')) {
        fetch('api/citas_delete.php',{method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:'id='+encodeURIComponent(info.event.id)})
          .then(r=>r.json()).then(()=>{ calendar.refetchEvents(); });
      }
    }
  });
  calendar.render();
  document.getElementById('formCita').addEventListener('submit', function(e){
    e.preventDefault();
    fetch('api/citas_save.php', { method:'POST', body: new FormData(this) })
      .then(r=>r.json()).then(()=>{ document.getElementById('msg').innerHTML='<div class="alert alert-success">Guardado</div>'; this.reset(); calendar.refetchEvents(); });
  });
});
</script>
<?php include 'partials/footer.php'; ?>
